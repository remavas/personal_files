when you wont set a password 
go tou youre folder___open notepad___then write



@echo off
color 0a
set /p password=ihr password=
if /I "%password%"=="<the password>" call loged in
exit

save it as "Password.bat" all files









to set account copy and paste "new account set.7z"
and un-zip
then edit <> in the information and enjoy

the key see you
